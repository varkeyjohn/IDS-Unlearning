### Clean model files

Please download the model files from [Google Drive](https://drive.google.com/file/d/1Ka5rWFxoGrcGd_5f7QrWYUPwomiWx5uG/view?usp=sharing) and unzip them.


